package com.javarush.jira.common;

public interface HasIdAndEmail extends HasId {
    String getEmail();
}