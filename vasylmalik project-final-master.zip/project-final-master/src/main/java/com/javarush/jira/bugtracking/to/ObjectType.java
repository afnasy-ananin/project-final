package com.javarush.jira.bugtracking.to;

public enum ObjectType {
    PROJECT,
    SPRINT,
    TASK
}
