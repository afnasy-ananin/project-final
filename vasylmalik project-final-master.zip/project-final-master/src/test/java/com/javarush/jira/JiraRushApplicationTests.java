package com.javarush.jira;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JiraRushApplicationTests {
	@Test
	void contextLoads() {
	}
}
